#include <Arduino.h>
#include <time.h>

extern void services_setup();
extern void services_loop();
extern void display_start_task_core0();

// Diese Werte müssen zu services.cpp passen:
static const char* TZ_INFO = "CET-1CEST-2,M3.5.0/02:00:00,M10.5.0/03:00:00";

void setup() {
  Serial.begin(115200);
  delay(100);

  // 1) Zeitzone so früh wie möglich setzen (vor RTC/mktime)
  setenv("TZ", TZ_INFO, 1);
  tzset();

  services_setup();
  display_start_task_core0();
}

void loop() {
  services_loop();
  delay(10);
}