#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <Preferences.h>
#include <Wire.h>
#include <RTClib.h>
#include <time.h>
#include <sys/time.h>
#include <esp_sntp.h>
#include <esp_wifi.h>
#include <cstdio>
#include <cstdarg>
#include <cstring>

// ===================== Konfiguration =====================
static constexpr bool CONTINUOUS_WIFI = false;

static const char* const NTP_SERVERS[] = {
  "de.pool.ntp.org",
  "pool.ntp.org",
  "time.google.com",
  "time.cloudflare.com"
};
static constexpr uint8_t NTP_SERVER_COUNT = sizeof(NTP_SERVERS) / sizeof(NTP_SERVERS[0]);

static const char* TZ_INFO    = "CET-1CEST-2,M3.5.0/02:00:00,M10.5.0/03:00:00";

static constexpr uint32_t UPDATE_DELAY_SEC     = 21600UL; // 6h
static constexpr uint32_t RETRY_DELAY_SEC      = 300UL;   // 5min
static constexpr uint32_t RTC_CHECK_DELAY_SEC  = 43200UL; // 12h

static constexpr uint32_t WIFI_CONNECT_TIMEOUT_MS = 30000UL;
static constexpr uint32_t NTP_WAIT_TIMEOUT_MS     = 20000UL;

static constexpr uint32_t MAINTENANCE_AP_TIMEOUT_SEC = 600UL; // 10min

static constexpr gpio_num_t AP_TOGGLE_BUTTON_PIN = GPIO_NUM_35;
static constexpr uint32_t AP_BUTTON_LONGPRESS_MS = 3000UL;
static constexpr uint32_t AP_BUTTON_DEBOUNCE_MS  = 50UL;

static constexpr int RTC_SDA_PIN = 16;
static constexpr int RTC_SCL_PIN = 17;

static constexpr const char* SETUP_AP_SSID = "MeterClock-Setup";
static constexpr const char* HOSTNAME      = "meterclock";

// ===================== Helpers =====================
static String htmlEscape(const String& in) {
  String out;
  out.reserve(in.length());
  for (size_t i = 0; i < in.length(); i++) {
    const char c = in[i];
    switch (c) {
      case '&': out += F("&amp;"); break;
      case '<': out += F("&lt;"); break;
      case '>': out += F("&gt;"); break;
      case '"': out += F("&quot;"); break;
      case '\'': out += F("&#39;"); break;
      default: out += c; break;
    }
  }
  return out;
}

static String urlEncode(const String& in) {
  String out;
  out.reserve(in.length() * 3);
  static const char* hex = "0123456789ABCDEF";
  for (size_t i = 0; i < in.length(); i++) {
    const uint8_t c = (uint8_t)in[i];
    const bool unreserved =
      (c >= 'a' && c <= 'z') ||
      (c >= 'A' && c <= 'Z') ||
      (c >= '0' && c <= '9') ||
      c == '-' || c == '_' || c == '.' || c == '~';

    if (unreserved) out += (char)c;
    else {
      out += '%';
      out += hex[(c >> 4) & 0x0F];
      out += hex[c & 0x0F];
    }
  }
  return out;
}

static String jsonEscape(const String& in) {
  String out;
  out.reserve(in.length() + 8);
  for (size_t i = 0; i < in.length(); i++) {
    const char c = in[i];
    switch (c) {
      case '\\': out += F("\\\\"); break;
      // JSON string quote
      case '"':  out += F("\\\""); break;
      case '\n': out += F("\\n"); break;
      case '\r': out += F("\\r"); break;
      case '\t': out += F("\\t"); break;
      default:
        if ((uint8_t)c < 0x20) {
          char buf[7];
          snprintf(buf, sizeof(buf), "\\u%04x", (unsigned)((uint8_t)c));
          out += buf;
        } else {
          out += c;
        }
        break;
    }
  }
  return out;
}


static int rssiToQualityPercent(int rssi) {
  if (rssi <= -100) return 0;
  if (rssi >= -50)  return 100;
  return 2 * (rssi + 100);
}

// ===================== RAM Log (Ringbuffer) =====================
namespace Log {
  static constexpr uint16_t kLines = 60;
  static constexpr uint16_t kLen   = 128;

  static char lines[kLines][kLen];
  static uint16_t head = 0;
  static bool filled = false;

  static portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;

  static void addf(const char* fmt, ...) {
    char msg[kLen];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);

    char finalLine[kLen];
    snprintf(finalLine, sizeof(finalLine), "[%lu] %s", (unsigned long)millis(), msg);

    portENTER_CRITICAL(&mux);
    strncpy(lines[head], finalLine, kLen - 1);
    lines[head][kLen - 1] = 0;
    head = (head + 1) % kLines;
    if (head == 0) filled = true;
    portEXIT_CRITICAL(&mux);
  }

  static uint16_t count() {
    portENTER_CRITICAL(&mux);
    const uint16_t c = filled ? kLines : head;
    portEXIT_CRITICAL(&mux);
    return c;
  }

  static void getLineNewestFirst(uint16_t idx, char* out, size_t outLen) {
    out[0] = 0;
    portENTER_CRITICAL(&mux);
    const uint16_t c = filled ? kLines : head;
    if (idx >= c) {
      portEXIT_CRITICAL(&mux);
      return;
    }
    int32_t newest = (int32_t)head - 1;
    if (newest < 0) newest += kLines;

    int32_t pos = newest - (int32_t)idx;
    while (pos < 0) pos += kLines;
    pos %= kLines;

    strncpy(out, lines[pos], outLen - 1);
    out[outLen - 1] = 0;
    portEXIT_CRITICAL(&mux);
  }
}

// ===================== State =====================
struct TimeState {
  bool timeValid = false;
  bool syncInProgress = false;

  bool lastSyncEver = false;
  bool lastSyncOk = false;

  unsigned long lastSyncMillis = 0;
  time_t lastSyncEpoch = 0;

  time_t nextSyncEpoch = 0;
  unsigned long nextRetryMillis = 0;

  bool rtcClockMode = false;
};

struct ApState {
  bool active = false;
  bool manual = false;
  unsigned long untilMs = 0;
};

// ===================== RTC Service =====================
class RtcService {
public:
  void begin();
  bool enabled() const { return _enabled; }
  bool detected() const { return _detected; }
  bool valid() const { return _timeValid; }

  void setEnabled(bool en);
  bool tryApplyRtcToSystem();
  bool writeSystemToRtc();
  bool setSystemTimeFromLocalTm(tm& localTm);

private:
  void loadSetting();
  void saveSetting();

private:
  RTC_DS3231 _rtc;
  Preferences _prefs;
  bool _enabled = false;
  bool _detected = false;
  bool _timeValid = false;
};

// forward declare
class NetworkService;

// ===================== Time Service (Declaration first) =====================
class TimeService {
public:
  void begin(NetworkService* net, RtcService* rtc);
  void loop();

  void requestSyncNow() { _syncNow = true; }
  const TimeState& state() const { return _st; }

  unsigned long lastSyncMinutesAgo() const;
  long nextSyncInSeconds() const;

private:
  enum class Phase : uint8_t { Idle, WaitWifi, StartNtp, WaitNtp, FinishedOk, FinishedFail };

  bool systemTimeValid() const;
  void scheduleNextAfterOk();
  void scheduleRetryNoTime();

private:
  NetworkService* _net = nullptr;
  RtcService* _rtc = nullptr;

  TimeState _st{};
  Phase _phase = Phase::Idle;

  unsigned long _wifiDeadlineMs = 0;
  unsigned long _ntpDeadlineMs = 0;

  uint32_t _ntpCounterStart = 0;
  volatile bool _syncNow = false;

  unsigned long _lastLoopMs = 0;

  // NTP fallback server rotation (primary + 3 fallbacks)
  uint8_t _ntpServerIndex = 0;
  uint8_t _ntpAttempt = 0;
};

// ===================== Network + Web + AP =====================
class NetworkService {
public:
  void begin(TimeService* timeSvc, RtcService* rtcSvc);
  void loop();

  // AP
  void startAp(bool manual);
  void stopAp();
  bool isApActive() const { return _ap.active; }
  bool isApManual() const { return _ap.manual; }
  void extendApTimeout();

  // STA
  void ensureStaConnectingKnown();
  void requestStaConnect(const String& ssid, const String& pass, bool triggerSyncAfterConnect);
  void requestForgetWifi();

  bool isStaConnected() const;
  bool staConnectFailed() const;
  bool isStaConnecting() const { return _staConnecting; }

  void abortStaConnect();
  void powerOffWifiIfAllowed();

private:
  void configureRoutes();

  // Web pages
  void handleRoot();
  void handleStatus();
  void handleLastUpdate();
  void handleLog();

  void handleWifiPage();
  void handleWifiSave();
  void handleWifiForget();
  void handleWifiReconnect();

  void handleWifiScanStart();
  void handleWifiScanData();
  void handleWifiScanCancel();
  void handleWifiScanView();

  void handleNtpSyncNow();

  void handleRtcPage();
  void handleRtcEnable();
  void handleRtcSet();

  void handleCaptiveRedirect();
  void handleNotFound();

  // internal helpers
  void serverBeginIfNeeded();
  void serverStopIfRunning();
  void captiveStartIfNeeded();
  void captiveStopIfRunning();

  void apTick();
  void staTick();
  void handleApButton();

  String staLinkSpeedInfo() const;

  void sendHeader(const __FlashStringHelper* title);
  void sendFooter();
  void sendNav();
  uint8_t activeTab();
  void sendRedirectPage(const char* title, uint8_t activeTab, const String& heading,
                        const String& message, const String& targetUrl, uint16_t delayMs);

private:
  TimeService* _time = nullptr;
  RtcService*  _rtc  = nullptr;

  WebServer _server{80};
  DNSServer _dns;
  bool _serverRunning = false;
  bool _dnsRunning = false;

  ApState _ap{};

  // STA state
  bool _staConnecting = false;
  bool _staFailed = false;
  unsigned long _staStartMs = 0;

  // Web-driven WiFi scan state (avoid scan/connect race + avoid restarting scans on refresh)
  bool _webScanActive = false;
  unsigned long _scanStartMs = 0;
  uint8_t _scanRetryCount = 0;
  uint8_t _scanZeroCount = 0;

  // queued actions
  String _pendingSsid;
  String _pendingPass;
  bool _pendingConnect = false;
  bool _pendingTriggerSync = false;
  bool _pendingForget = false;

  // deferred begin (no delay)
  bool _beginDeferred = false;
  unsigned long _beginAtMs = 0;
  String _beginSsid;
  String _beginPass;

  // AP button debounce/longpress
  bool _btnRawLast = false;
  bool _btnStable = false;
  unsigned long _btnLastChangeMs = 0;
  unsigned long _btnPressStartMs = 0;
  bool _btnActionDone = false;
};

// ===================== SNTP callback counter =====================
static volatile uint32_t gNtpSyncEventCounter = 0;
static volatile bool gNtpSyncEventFlag = false;

static void ntpTimeSyncCallback(struct timeval* tv) {
  (void)tv;
  gNtpSyncEventCounter++;
  gNtpSyncEventFlag = true;
}
// ===================== RtcService impl =====================
void RtcService::loadSetting() {
  _prefs.begin("meterclock", true);
  _enabled = _prefs.getBool("rtc_en", false);
  _prefs.end();
}

void RtcService::saveSetting() {
  _prefs.begin("meterclock", false);
  _prefs.putBool("rtc_en", _enabled);
  _prefs.end();
}

void RtcService::begin() {
  loadSetting();
  Wire.begin(RTC_SDA_PIN, RTC_SCL_PIN);

  if (!_enabled) {
    _detected = false;
    _timeValid = false;
    return;
  }

  _detected = _rtc.begin();
  _timeValid = _detected ? !_rtc.lostPower() : false;
  Log::addf("RTC begin: enabled=%d detected=%d valid=%d", (int)_enabled, (int)_detected, (int)_timeValid);
}

void RtcService::setEnabled(bool en) {
  _enabled = en;
  saveSetting();

  if (!_enabled) {
    _detected = false;
    _timeValid = false;
    Log::addf("RTC disabled");
    return;
  }

  _detected = _rtc.begin();
  _timeValid = _detected ? !_rtc.lostPower() : false;
  Log::addf("RTC enabled: detected=%d valid=%d", (int)_detected, (int)_timeValid);
}

bool RtcService::tryApplyRtcToSystem() {
  if (!_enabled) return false;

  _detected = _rtc.begin();
  if (!_detected) {
    _timeValid = false;
    return false;
  }
  _timeValid = !_rtc.lostPower();
  if (!_timeValid) return false;

  const DateTime dt = _rtc.now();

  tm tLocal{};
  tLocal.tm_year = dt.year() - 1900;
  tLocal.tm_mon  = dt.month() - 1;
  tLocal.tm_mday = dt.day();
  tLocal.tm_hour = dt.hour();
  tLocal.tm_min  = dt.minute();
  tLocal.tm_sec  = dt.second();
  tLocal.tm_isdst = -1;

  const time_t epoch = mktime(&tLocal);
  if (epoch <= 100000) return false;

  timeval tv{};
  tv.tv_sec = epoch;
  tv.tv_usec = 0;

  const bool ok = (settimeofday(&tv, nullptr) == 0);
  Log::addf("RTC -> system time %s", ok ? "OK" : "FAIL");
  return ok;
}

bool RtcService::writeSystemToRtc() {
  if (!_enabled) return false;

  _detected = _rtc.begin();
  if (!_detected) return false;

  time_t now;
  time(&now);
  if (now <= 100000) return false;

  tm localTm{};
  if (!localtime_r(&now, &localTm)) return false;

  DateTime dt(localTm.tm_year + 1900,
              localTm.tm_mon + 1,
              localTm.tm_mday,
              localTm.tm_hour,
              localTm.tm_min,
              localTm.tm_sec);

  _rtc.adjust(dt);
  _timeValid = true;
  Log::addf("System -> RTC write OK");
  return true;
}

bool RtcService::setSystemTimeFromLocalTm(tm& localTm) {
  localTm.tm_isdst = -1;
  const time_t epoch = mktime(&localTm);
  if (epoch <= 100000) return false;

  timeval tv{};
  tv.tv_sec = epoch;
  tv.tv_usec = 0;

  if (settimeofday(&tv, nullptr) != 0) return false;

  Log::addf("Manual system time set OK");
  writeSystemToRtc();
  return true;
}

// ===================== NetworkService impl =====================
void NetworkService::begin(TimeService* timeSvc, RtcService* rtcSvc) {
  _time = timeSvc;
  _rtc = rtcSvc;

  WiFi.persistent(true);
  WiFi.setAutoReconnect(false);
  WiFi.setHostname(HOSTNAME);
  WiFi.mode(WIFI_OFF);

  pinMode((int)AP_TOGGLE_BUTTON_PIN, INPUT);

  configureRoutes();

  if (CONTINUOUS_WIFI) {
    WiFi.mode(WIFI_STA);
    WiFi.setSleep(false);
    WiFi.begin();
    serverBeginIfNeeded();
    Log::addf("CONTINUOUS_WIFI: server started, STA begin()");
  }
}

void NetworkService::loop() {
  if (_serverRunning) _server.handleClient();
  if (_dnsRunning) _dns.processNextRequest();

  handleApButton();
  apTick();
  staTick();
}

void NetworkService::configureRoutes() {
  _server.on("/", HTTP_GET, [this](){ handleRoot(); });
  _server.on("/status", HTTP_GET, [this](){ handleStatus(); });
  _server.on("/lastupdate", HTTP_GET, [this](){ handleLastUpdate(); });
  _server.on("/log", HTTP_GET, [this](){ handleLog(); });

  _server.on("/wifi", HTTP_GET, [this](){ handleWifiPage(); });
  _server.on("/wifi/scanstart", HTTP_GET, [this](){ handleWifiScanStart(); });
  _server.on("/wifi/scandata", HTTP_GET, [this](){ handleWifiScanData(); });
  _server.on("/wifi/scancancel", HTTP_GET, [this](){ handleWifiScanCancel(); });
  _server.on("/wifi/scanview", HTTP_GET, [this](){ handleWifiScanView(); });
  // Legacy route: keep it.
  _server.on("/wifi/scan", HTTP_GET, [this](){
    _server.sendHeader("Location", "/wifi/scanview?start=1", true);
    _server.send(303, "text/plain", "");
  });
  _server.on("/wifi/save", HTTP_POST, [this](){ handleWifiSave(); });
  _server.on("/wifi/forget", HTTP_POST, [this](){ handleWifiForget(); });
  _server.on("/wifi/reconnect", HTTP_POST, [this](){ handleWifiReconnect(); });

  _server.on("/ntp/sync", HTTP_POST, [this](){ handleNtpSyncNow(); });

  _server.on("/rtc", HTTP_GET, [this](){ handleRtcPage(); });
  _server.on("/rtc/enable", HTTP_POST, [this](){ handleRtcEnable(); });
  _server.on("/rtc/set", HTTP_POST, [this](){ handleRtcSet(); });

  _server.on("/generate_204", HTTP_GET, [this](){ handleCaptiveRedirect(); });
  _server.on("/fwlink", HTTP_GET, [this](){ handleCaptiveRedirect(); });
  _server.on("/hotspot-detect.html", HTTP_GET, [this](){ handleCaptiveRedirect(); });
  _server.on("/connecttest.txt", HTTP_GET, [this](){ handleCaptiveRedirect(); });
  _server.on("/ncsi.txt", HTTP_GET, [this](){ handleCaptiveRedirect(); });

  _server.onNotFound([this](){ handleNotFound(); });
}

void NetworkService::serverBeginIfNeeded() {
  if (_serverRunning) return;
  _server.begin();
  _serverRunning = true;
}

void NetworkService::serverStopIfRunning() {
  if (!_serverRunning) return;
  _server.stop();
  _serverRunning = false;
}

void NetworkService::captiveStartIfNeeded() {
  if (_dnsRunning) return;
  _dns.setErrorReplyCode(DNSReplyCode::NoError);
  _dns.start(53, "*", WiFi.softAPIP());
  _dnsRunning = true;
}

void NetworkService::captiveStopIfRunning() {
  if (!_dnsRunning) return;
  _dns.stop();
  _dnsRunning = false;
}

void NetworkService::extendApTimeout() {
  if (!_ap.active) return;
  _ap.untilMs = millis() + (MAINTENANCE_AP_TIMEOUT_SEC * 1000UL);

  // Track STA connect state properly when AP starts (stored creds)
  ensureStaConnectingKnown();

  // Track STA connect state properly when AP starts (stored creds)
  ensureStaConnectingKnown();
}

void NetworkService::startAp(bool manual) {
  if (CONTINUOUS_WIFI) return;

  if (_ap.active) {
    if (manual) _ap.manual = true;
    extendApTimeout();
    return;
  }

  WiFi.mode(WIFI_AP_STA);
  WiFi.setSleep(false);

  WiFi.softAP(SETUP_AP_SSID);

  serverBeginIfNeeded();
  captiveStartIfNeeded();

  _ap.active = true;
  _ap.manual = manual;
  _ap.untilMs = millis() + (MAINTENANCE_AP_TIMEOUT_SEC * 1000UL);
  // Track STA connect state properly when AP starts (stored creds)
  ensureStaConnectingKnown();

  Log::addf("AP started (manual=%d), IP=%s", (int)manual, WiFi.softAPIP().toString().c_str());
}

void NetworkService::stopAp() {
  if (!_ap.active) return;

  serverStopIfRunning();
  captiveStopIfRunning();
  WiFi.softAPdisconnect(true);

  _ap.active = false;
  _ap.manual = false;
  _ap.untilMs = 0;

  Log::addf("AP stopped");
  powerOffWifiIfAllowed();
}

void NetworkService::apTick() {
  if (!_ap.active) return;
  if ((long)(millis() - _ap.untilMs) >= 0) {
    const int clients = WiFi.softAPgetStationNum();
    if (clients > 0) {
      _ap.untilMs = millis() + 60000UL; // keep AP alive while clients are connected
      Log::addf("AP timeout but %d client(s) connected -> extend 60s", clients);
      return;
    }
    Log::addf("AP timeout -> stop");
    stopAp();
  }
}
bool NetworkService::isStaConnected() const { return WiFi.status() == WL_CONNECTED; }
bool NetworkService::staConnectFailed() const { return _staFailed; }

void NetworkService::ensureStaConnectingKnown() {
  if (isStaConnected()) { _staConnecting = false; _staFailed = false; return; }
  if (_staConnecting) return;

  // While the user is actively scanning via the web UI, avoid starting background STA connects.
  // This prevents the ESP-IDF WiFi stack from cancelling/never completing scans.
  if (_webScanActive) return;

  if (_ap.active) WiFi.mode(WIFI_AP_STA);
  else WiFi.mode(WIFI_STA);

  WiFi.setSleep(false);
  WiFi.begin();

  _staConnecting = true;
  _staFailed = false;
  _staStartMs = millis();
  Log::addf("STA begin() stored creds");
}

void NetworkService::requestStaConnect(const String& ssid, const String& pass, bool triggerSyncAfterConnect) {
  _pendingSsid = ssid;
  _pendingPass = pass;
  _pendingConnect = true;
  _pendingTriggerSync = triggerSyncAfterConnect;
}

void NetworkService::requestForgetWifi() {
  _pendingForget = true;
}

void NetworkService::abortStaConnect() {
  WiFi.disconnect(false, false);
  _staConnecting = false;
  _staFailed = true;
  _beginDeferred = false;
  Log::addf("STA connect aborted");
}

void NetworkService::powerOffWifiIfAllowed() {
  if (CONTINUOUS_WIFI) return;
  if (_ap.active) return;
  if (_staConnecting) return;

  WiFi.disconnect(false);
  WiFi.mode(WIFI_OFF);
  Log::addf("WiFi OFF");
}

void NetworkService::staTick() {
  if (_pendingForget) {
    _pendingForget = false;
    WiFi.disconnect(false, true);
    _staConnecting = false;
    _staFailed = true;
    _beginDeferred = false;
    Log::addf("WiFi credentials erased");
  }

  if (_pendingConnect) {
    _pendingConnect = false;

    if (_ap.active) WiFi.mode(WIFI_AP_STA);
    else WiFi.mode(WIFI_STA);

    WiFi.setSleep(false);

    // Ensure new credentials replace old ones reliably
    WiFi.disconnect(false, true);

    _beginSsid = _pendingSsid;
    _beginPass = _pendingPass;
    _beginDeferred = true;
    _beginAtMs = millis() + 30;

    _staConnecting = true;
    _staFailed = false;
    _staStartMs = millis();

    Log::addf("STA connect requested ssid='%s' (deferred)", _beginSsid.c_str());
  }

  if (_beginDeferred && (long)(millis() - _beginAtMs) >= 0) {
    _beginDeferred = false;
    WiFi.begin(_beginSsid.c_str(), _beginPass.c_str());
    Log::addf("STA begin() ssid='%s'", _beginSsid.c_str());
  }

  if (!_staConnecting) return;

  const wl_status_t st = WiFi.status();
  if (st == WL_CONNECTED) {
    _staConnecting = false;
    _staFailed = false;

    Log::addf("STA connected: SSID='%s' RSSI=%d IP=%s",
              WiFi.SSID().c_str(), (int)WiFi.RSSI(), WiFi.localIP().toString().c_str());

    if (CONTINUOUS_WIFI) {
      WiFi.setSleep(true);
      esp_wifi_set_ps(WIFI_PS_MIN_MODEM);
    }

    if (_pendingTriggerSync && _time) _time->requestSyncNow();
    _pendingTriggerSync = false;
    return;
  }

  if (st == WL_CONNECT_FAILED || st == WL_NO_SSID_AVAIL) {
    _staConnecting = false;
    _staFailed = true;
    _pendingTriggerSync = false;
    Log::addf("STA connect failed (status=%d)", (int)st);
    return;
  }

  if (millis() - _staStartMs >= WIFI_CONNECT_TIMEOUT_MS) {
    _staConnecting = false;
    _staFailed = true;
    _pendingTriggerSync = false;
    Log::addf("STA connect timeout");
    return;
  }
}

void NetworkService::handleApButton() {
  const bool raw = (digitalRead((int)AP_TOGGLE_BUTTON_PIN) == HIGH);
  const unsigned long nowMs = millis();

  if (raw != _btnRawLast) {
    _btnRawLast = raw;
    _btnLastChangeMs = nowMs;
  }

  if (nowMs - _btnLastChangeMs < AP_BUTTON_DEBOUNCE_MS) return;

  if (_btnStable != raw) {
    _btnStable = raw;
    if (_btnStable) {
      _btnPressStartMs = nowMs;
      _btnActionDone = false;
    } else {
      _btnActionDone = false;
    }
  }

  if (_btnStable && !_btnActionDone) {
    if (nowMs - _btnPressStartMs >= AP_BUTTON_LONGPRESS_MS) {
      _btnActionDone = true;
      if (!_ap.active) startAp(true);
      else extendApTimeout();
    }
  }
}

String NetworkService::staLinkSpeedInfo() const {
  if (WiFi.status() != WL_CONNECTED) return F("-");

  wifi_ap_record_t apinfo;
  memset(&apinfo, 0, sizeof(apinfo));
  if (esp_wifi_sta_get_ap_info(&apinfo) != ESP_OK) return F("-");

  wifi_bandwidth_t bw = WIFI_BW_HT20;
  esp_wifi_get_bandwidth(WIFI_IF_STA, &bw);
  const bool bw40 = (bw == WIFI_BW_HT40);

  String phy = F("unbekannt");
  int maxMbit = 0;

  if (apinfo.phy_11n) { phy = F("802.11n"); maxMbit = bw40 ? 150 : 72; }
  else if (apinfo.phy_11g) { phy = F("802.11g"); maxMbit = 54; }
  else if (apinfo.phy_11b) { phy = F("802.11b"); maxMbit = 11; }

  String s = phy;
  s += bw40 ? F(" (40 MHz)") : F(" (20 MHz)");
  if (maxMbit > 0) { s += F(", ~"); s += String(maxMbit); s += F(" Mbit/s (max)"); }
  return s;
}

void NetworkService::sendHeader(const __FlashStringHelper* title) {
  _server.setContentLength(CONTENT_LENGTH_UNKNOWN);

  // Stabiler für Captive-Portal / mobile Browser:
  _server.sendHeader("Cache-Control", "no-store");
  _server.sendHeader("Connection", "close");

  _server.send(200, "text/html; charset=utf-8", "");
  _server.sendContent(F("<html><head><meta charset='utf-8'>"
                        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                        "<title>"));
  _server.sendContent(title);
  _server.sendContent(F("</title>"
                        "<style>"
                        ":root{--bg:#0b0f19;--card:#111827;--text:#e5e7eb;--muted:#9ca3af;--line:#1f2937;--accent:#10a37f;}"
                        "body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;"
                        "background:var(--bg);color:var(--text);}"
                        ".wrap{max-width:860px;margin:0 auto;padding:16px;}"
                        ".nav{display:flex;flex-wrap:wrap;gap:8px;position:sticky;top:0;background:rgba(11,15,25,.92);"
                        "backdrop-filter:blur(6px);padding:12px 16px;border-bottom:1px solid var(--line);}"
                        ".tab{display:inline-block;padding:10px 12px;border-radius:10px;text-decoration:none;"
                        "color:var(--text);border:1px solid var(--line);background:#0f172a;font-weight:600;}"
                        ".tab.active{border-color:var(--accent);color:var(--accent);}"
                        ".card{background:var(--card);border:1px solid var(--line);border-radius:14px;"
                        "padding:14px;margin:12px 0;box-shadow:0 1px 0 rgba(0,0,0,.03);}"
                        ".grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px;}"
                        "h1,h2,h3{margin:0 0 10px 0;}"
                        "p{margin:8px 0;line-height:1.35;}"
                        ".muted{color:var(--muted);}"
                        "button{padding:10px 12px;border-radius:10px;border:1px solid var(--line);"
                        "background:#0f172a;color:var(--text);font-weight:600;}"
                        "button.primary{border-color:var(--accent);color:#06121a;background:var(--accent);}"
                        "input{width:100%;padding:10px 12px;border-radius:10px;border:1px solid var(--line);"
                        "font-size:16px;box-sizing:border-box;background:#0b1220;color:var(--text);}"
                        ".row{display:flex;gap:10px;align-items:center;flex-wrap:wrap;}"
                        ".list{list-style:none;padding-left:0;margin:8px 0;}"
                        ".list li{padding:10px 10px;border:1px solid var(--line);border-radius:12px;margin:8px 0;}"
                        "code{background:#0f172a;padding:2px 6px;border-radius:8px;border:1px solid var(--line);}"
                        "a{color:var(--accent);}"
                        ".bar{height:10px;border-radius:999px;background:#0f172a;border:1px solid var(--line);overflow:hidden;}"
                        ".barin{height:100%;background:var(--accent);border-radius:999px;}"
                        "details{margin-top:10px;}"
                        "</style>"
                        "</head><body>"));

  // Navigation (Tabs): Home, WiFi, Log
  sendNav();
  _server.sendContent(F("<div class='wrap'>"));
}

void NetworkService::sendFooter() {
  _server.sendContent(F("</div></body></html>"));

  // IMPORTANT: End chunked transfer, sonst liefern manche Clients nur Teilinhalte (z.B. nur "SSID").
  _server.sendContent("");
}

uint8_t NetworkService::activeTab() {
  const String u = _server.uri();
  if (u.startsWith("/wifi")) return 1;
  if (u.startsWith("/log"))  return 2;
  return 0;
}

void NetworkService::sendNav() {
  const uint8_t active = activeTab();
  _server.sendContent(F("<div class='nav'>"));

  _server.sendContent(F("<a class='tab "));
  _server.sendContent(active == 0 ? F("active") : F(""));
  _server.sendContent(F("' href='/'>Home</a>"));

  _server.sendContent(F("<a class='tab "));
  _server.sendContent(active == 1 ? F("active") : F(""));
  _server.sendContent(F("' href='/wifi'>WiFi</a>"));

  _server.sendContent(F("<a class='tab "));
  _server.sendContent(active == 2 ? F("active") : F(""));
  _server.sendContent(F("' href='/log'>Log</a>"));

  _server.sendContent(F("</div>"));
}



// ===================== Web UI: non-chunked pages for stability =====================
static void pageBegin(String& out, const char* title, uint8_t activeTab) {
  out += F("<!doctype html><html><head><meta charset='utf-8'>"
           "<meta name='viewport' content='width=device-width,initial-scale=1'>"
           "<meta http-equiv='Cache-Control' content='no-store'>"
           "<title>");
  out += title;
  out += F("</title>"
           "<style>"
           ":root{--bg:#0b0f19;--card:#111827;--text:#e5e7eb;--muted:#9ca3af;--line:#1f2937;--accent:#10a37f;}"
           "body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;background:var(--bg);color:var(--text);}"
           ".wrap{max-width:860px;margin:0 auto;padding:16px;}"
           ".nav{display:flex;flex-wrap:wrap;gap:8px;padding:12px 16px;border-bottom:1px solid var(--line);background:rgba(11,15,25,.96);position:sticky;top:0;backdrop-filter:blur(6px);}"
           ".tab{display:inline-block;padding:10px 12px;border-radius:10px;text-decoration:none;color:var(--text);border:1px solid var(--line);background:#0f172a;font-weight:600;}"
           ".tab.active{border-color:var(--accent);color:var(--accent);}"
           ".card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px;margin:12px 0;box-shadow:0 1px 0 rgba(0,0,0,.03);}"
           ".grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px;}"
           "h2,h3{margin:0 0 10px 0;}"
           "p{margin:8px 0;line-height:1.35;}"
           ".muted{color:var(--muted);}"
	           "button,.btn{padding:10px 12px;border-radius:10px;border:1px solid var(--line);background:#0f172a;color:var(--text);font-weight:600;display:inline-block;text-decoration:none;}"
           "button.primary{border-color:var(--accent);color:#06121a;background:var(--accent);}"
	           ".btn.primary{border-color:var(--accent);color:#06121a;background:var(--accent);}"
           "input{width:100%;padding:10px 12px;border-radius:10px;border:1px solid var(--line);font-size:16px;box-sizing:border-box;background:#0b1220;color:var(--text);}"
           ".row{display:flex;gap:10px;align-items:center;flex-wrap:wrap;}"
           ".list{list-style:none;padding-left:0;margin:8px 0;}"
           ".list li{padding:10px 10px;border:1px solid var(--line);border-radius:12px;margin:8px 0;}"
           "code{background:#0f172a;padding:2px 6px;border-radius:8px;border:1px solid var(--line);}"
           "a{color:var(--accent);}"
           ".bar{height:10px;border-radius:999px;background:#0f172a;border:1px solid var(--line);overflow:hidden;}"
           ".barin{height:100%;background:var(--accent);border-radius:999px;}"
           "</style></head><body>");

  // Tabs: Home, WiFi, Log
  out += F("<div class='nav'>");

  out += F("<a class='tab ");
  out += (activeTab == 0) ? F("active") : F("");
  out += F("' href='/'>Home</a>");

  out += F("<a class='tab ");
  out += (activeTab == 1) ? F("active") : F("");
  out += F("' href='/wifi'>WiFi</a>");

  out += F("<a class='tab ");
  out += (activeTab == 2) ? F("active") : F("");
  out += F("' href='/log'>Log</a>");

  out += F("</div><div class='wrap'>");
}

static void pageEnd(String& out) {
  out += F("</div></body></html>");
}

void NetworkService::sendRedirectPage(const char* title, uint8_t tab, const String& heading,
                                      const String& message, const String& targetUrl, uint16_t delayMs) {
  String out;
  if (!out.reserve(4000)) { _server.send(500, "text/plain", "OOM"); return; }
  pageBegin(out, title, tab);

  out += F("<h2>");
  out += heading;
  out += F("</h2>");

  out += F("<div class='card'><h3>");
  out += heading;
  out += F("</h3><p>");
  out += message;
  out += F("</p><div style='height:10px'></div><div class='bar'><div class='barin' style='width:35%'></div></div>"
           "<p class='muted'>Bitte warten... (automatische Weiterleitung)</p><p><a href='");
  out += targetUrl;
  out += F("'>Wenn nichts passiert, hier klicken</a></p></div>");

  out += F("<script>(function(){var u='");
  out += targetUrl;
  out += F("';var p=u.split('#');var base=p[0];var frag=(p.length>1)?('#'+p.slice(1).join('#')):'';var sep=(base.indexOf('?')>=0)?'&':'?';setTimeout(function(){location.replace(base+sep+'_='+Date.now()+frag);},");
  out += String((unsigned)delayMs);
  out += F(");})();</script>");

  pageEnd(out);
  _server.send(200, "text/html; charset=utf-8", out);
}
void NetworkService::handleRoot() {
  if (_ap.active) extendApTimeout();

  const TimeState ts = _time ? _time->state() : TimeState{};
  const unsigned long lastMin = _time ? _time->lastSyncMinutesAgo() : 0;
  const long nextInSec = _time ? _time->nextSyncInSeconds() : -1;

  String out;
  if (!out.reserve(9000)) { _server.send(500, "text/plain", "OOM"); return; }
  pageBegin(out, "MeterClock", 0);

  out += F("<h2>MeterClock</h2>");

  time_t now;
  time(&now);

  out += F("<div class='grid'>");

  // Zeit
  out += F("<div class='card'><h3>Zeit</h3>");
  if (now <= 100000) {
    out += F("<p><b>Status:</b> <span class='muted'>noch nicht synchronisiert</span></p>");
  } else {
    tm localTm{};
    if (localtime_r(&now, &localTm)) {
      char buf[64];
      strftime(buf, sizeof(buf), "%d.%m.%Y %H:%M:%S", &localTm);
      out += F("<p><b>Aktuell:</b><br><code>");
      out += buf;
      out += F("</code></p>");
    }
  }

  out += F("<p><b>Letzter NTP Sync:</b> ");
  if (!ts.lastSyncEver || ts.lastSyncMillis == 0) out += F("<span class='muted'>nie</span>");
  else { out += String(lastMin); out += F(" min"); }

  out += F("<br><b>Sync l&auml;uft:</b> ");
  out += ts.syncInProgress ? F("Ja") : F("Nein");

  if (nextInSec >= 0) {
    out += F("<br><b>N&auml;chster Sync:</b> ");
    out += String(nextInSec);
    out += F(" s");
  }

  out += F("</p><form method='POST' action='/ntp/sync'>"
           "<button class='primary' type='submit'>Jetzt synchronisieren</button>"
           "</form></div>");

  // WiFi
  out += F("<div class='card'><h3>WiFi</h3>");
  if (WiFi.status() == WL_CONNECTED) {
    const int rssi = WiFi.RSSI();
    const int q = rssiToQualityPercent(rssi);
    out += F("<p><b>Verbunden:</b> ");
    out += htmlEscape(WiFi.SSID());
    out += F("<br><b>Signal:</b> ");
    out += String(q);
    out += F("% (");
    out += String(rssi);
    out += F(" dBm)");
    out += F("<div class='bar' style='margin-top:8px'><div class='barin' style='width:");
    out += String(q);
    out += F("%'></div></div>");
    out += F("<br><b>Link:</b> ");
    out += htmlEscape(staLinkSpeedInfo());
    out += F("<br><b>IP:</b> ");
    out += WiFi.localIP().toString();
    out += F("</p>");
  } else if (_staConnecting) {
    out += F("<p><b>Status:</b> <span class='muted'>Verbinde...</span></p>");
  } else {
    out += F("<p><b>Status:</b> <span class='muted'>nicht verbunden</span></p>"
             "<form method='POST' action='/wifi/reconnect'>"
             "<button type='submit'>Reconnect</button>"
             "</form>");
  }

  if (_ap.active) {
    out += F("<p><b>Setup-AP:</b> aktiv (<code>");
    out += SETUP_AP_SSID;
    out += F("</code>)<br><b>AP IP:</b> ");
    out += WiFi.softAPIP().toString();
    out += F("<br><b>Clients:</b> ");
    out += String(WiFi.softAPgetStationNum());
    out += F("</p><p class='muted'>Hinweis: Setup-AP bleibt an, solange Clients verbunden sind.</p>");
  }

  out += F("<p><a href='/wifi'>WiFi-Einstellungen &rarr;</a></p></div>");

  // RTC
  if (_rtc) {
    out += F("<div class='card'><h3>RTC (DS3231)</h3>");
    out += F("<p><b>Aktiviert:</b> ");
    out += _rtc->enabled() ? F("Ja") : F("Nein");
    out += F("<br><b>Erkannt:</b> ");
    out += _rtc->detected() ? F("Ja") : F("Nein");
    out += F("<br><b>Zeit g&uuml;ltig:</b> ");
    out += _rtc->valid() ? F("Ja") : F("Nein");
    out += F("</p>");

    out += F("<form method='POST' action='/rtc/enable' class='row'>"
             "<input type='hidden' name='enabled' value='");
    out += _rtc->enabled() ? F("0") : F("1");
    out += F("'>"
             "<button type='submit'>");
    out += _rtc->enabled() ? F("RTC deaktivieren") : F("RTC aktivieren");
    out += F("</button></form>");

    out += F("<details><summary class='muted'>Zeit manuell setzen</summary>"
             "<form method='POST' action='/rtc/set' style='margin-top:10px'>"
             "<input type='datetime-local' name='datetime' required>"
             "<div style='height:10px'></div>"
             "<button type='submit'>Zeit setzen</button>"
             "</form></details>");

    out += F("</div>");
  }

  out += F("</div>"); // grid

  pageEnd(out);
  _server.send(200, "text/html; charset=utf-8", out);
}

void NetworkService::handleStatus() {
  if (_ap.active) extendApTimeout();

  // WICHTIG: temporäre Strings vermeiden -> stabiler
  const String ssidStr = WiFi.SSID();
  const String ipStr   = WiFi.localIP().toString();

  const long nextInSec = _time ? _time->nextSyncInSeconds() : -1;
  const unsigned long lastMin = _time ? _time->lastSyncMinutesAgo() : 0;

  const TimeState ts = _time ? _time->state() : TimeState{};

  char buf[900];
  snprintf(buf, sizeof(buf),
           "timeValid=%s\n"
           "syncInProgress=%s\n"
           "lastSyncEver=%s\n"
           "lastSyncOk=%s\n"
           "lastSyncMinutesAgo=%lu\n"
           "nextSyncInSec=%ld\n"
           "apActive=%s\n"
           "apManual=%s\n"
           "wifiMode=%d\n"
           "staStatus=%d\n"
           "staSSID=%s\n"
           "staRSSI=%d\n"
           "staIP=%s\n",
           ts.timeValid ? "true" : "false",
           ts.syncInProgress ? "true" : "false",
           ts.lastSyncEver ? "true" : "false",
           ts.lastSyncOk ? "true" : "false",
           lastMin,
           nextInSec,
           _ap.active ? "true" : "false",
           _ap.manual ? "true" : "false",
           (int)WiFi.getMode(),
           (int)WiFi.status(),
           ssidStr.c_str(),
           (int)WiFi.RSSI(),
           ipStr.c_str());

  _server.send(200, "text/plain", buf);
}

void NetworkService::handleLastUpdate() {
  if (_ap.active) extendApTimeout();
  if (!_time) { _server.send(200, "text/plain", "n/a"); return; }

  const auto& st = _time->state();
  if (!st.lastSyncEver || st.lastSyncMillis == 0) {
    _server.send(200, "text/plain", "never");
    return;
  }
  char buf[32];
  snprintf(buf, sizeof(buf), "%lu", (unsigned long)((millis() - st.lastSyncMillis) / 60000UL));
  _server.send(200, "text/plain", buf);
}

void NetworkService::handleLog() {
  if (_ap.active) extendApTimeout();

  String out;
  if (!out.reserve(9500)) { _server.send(500, "text/plain", "OOM"); return; }
  pageBegin(out, "Log", 2);

  out += F("<div class='card'><h3>Log</h3>"
           "<pre style='white-space:pre-wrap;margin:0'>");

  const uint16_t c = Log::count();
  char line[Log::kLen];
  for (uint16_t i = 0; i < c; i++) {
    Log::getLineNewestFirst(i, line, sizeof(line));
    // Minimal escaping: avoid breaking HTML if a log line contains '<' or '&'
    out += htmlEscape(String(line));
    out += "\n";
  }

  out += F("</pre></div>");
  pageEnd(out);
  _server.send(200, "text/html; charset=utf-8", out);
}

void NetworkService::handleNtpSyncNow() {
  if (_ap.active) extendApTimeout();
  if (_time) _time->requestSyncNow();
  Log::addf("NTP sync requested via web");

  // UX: Zur&uuml;ck auf die Startseite (Status dort sichtbar)
  _server.sendHeader("Location", "/", true);
  _server.send(303, "text/plain", "");
}


void NetworkService::handleWifiPage() {
  if (_ap.active) extendApTimeout();

  const String prefillSsid = _server.hasArg("ssid") ? _server.arg("ssid") : String();
  const String prefillSsidEnc = urlEncode(prefillSsid);
  const bool connectingMode = _server.hasArg("connecting") && (_server.arg("connecting") == "1");

  String out;
  if (!out.reserve(16000)) { _server.send(500, "text/plain", "OOM"); return; }
  pageBegin(out, "WiFi", 1);

  out += F("<h2>WiFi</h2>");

  // Status
  out += F("<div class='card'><h3>Status</h3>");
  if (_ap.active) {
    out += F("<p><b>AP SSID:</b> ");
    out += SETUP_AP_SSID;
    out += F("<br><b>AP IP:</b> ");
    out += WiFi.softAPIP().toString();
    out += F("<br><b>Clients:</b> ");
    out += String(WiFi.softAPgetStationNum());
    out += F("<br><b>Auto-Stop:</b> ");
    out += _ap.manual ? F("Timeout (nicht nach Sync)") : F("Sync oder Timeout");
    out += F("</p>");
  } else {
    out += F("<p class='muted'>Wartungs-AP ist aktuell nicht aktiv.</p>");
  }

  if (WiFi.status() == WL_CONNECTED) {
    const int rssi = WiFi.RSSI();
    const int q = rssiToQualityPercent(rssi);
    out += F("<p><b>STA:</b> verbunden mit ");
    out += htmlEscape(WiFi.SSID());
    out += F("<br><b>IP:</b> ");
    out += WiFi.localIP().toString();
    out += F("<br><b>Signal:</b> ");
    out += String(q);
    out += F("% (");
    out += String(rssi);
    out += F(" dBm)");
    out += F("<div class='bar' style='margin-top:8px'><div class='barin' style='width:");
    out += String(q);
    out += F("%'></div></div>");
    out += F("<br><b>Link:</b> ");
    out += htmlEscape(staLinkSpeedInfo());
    out += F("</p>");
  } else if (_staConnecting) {
    out += F("<p><b>STA:</b> <span class='muted'>Verbinde...</span></p>");
  } else {
    out += F("<p><b>STA:</b> <span class='muted'>nicht verbunden</span></p>"
             "<form method='POST' action='/wifi/reconnect'>"
             "<button type='submit'>Reconnect</button>"
             "</form>");
  }
  out += F("</div>");

  // Connect progress / result
  if (connectingMode) {
    out += F("<div class='card'><h3>Verbindung</h3>");
    if (WiFi.status() == WL_CONNECTED) {
      out += F("<p><b>Erfolgreich verbunden.</b></p><p class='muted'>Weiterleitung zur WiFi-&Uuml;bersicht...</p>");
      out += F("<script>setTimeout(function(){location.replace('/wifi?_=' + Date.now() + '#wifi-form');},700);</script>");
    } else if (_staConnecting) {
      const unsigned long elapsed = (unsigned long)(millis() - _staStartMs);
      int pct = 10 + (int)((elapsed * 80UL) / WIFI_CONNECT_TIMEOUT_MS);
      if (pct > 90) pct = 90;
      out += F("<p class='muted'>Verbinde... bitte warten</p>");
      out += F("<div style='height:8px'></div><div class='bar'><div class='barin' style='width:");
      out += String(pct);
      out += F("%'></div></div>");
      out += F("<script>setTimeout(function(){location.replace('/wifi?connecting=1&ssid=");
      out += prefillSsidEnc;
      out += F("&_=' + Date.now() + '#wifi-form');},1200);</script>");
    } else {
      out += F("<p><b>Verbindung fehlgeschlagen.</b></p><p class='muted'>Bitte SSID/Passwort pr&uuml;fen und erneut versuchen.</p>");
      out += F("<p><a href='/wifi#wifi-form'>Zur&uuml;ck</a></p>");
    }
    out += F("</div>");
  }

  // Change WiFi + Scan inline
  out += F("<div class='card' id='wifi-form'><h3>WLAN &auml;ndern</h3>"
           "<form id='wifisave' method='POST' action='/wifi/save'>"
           "<label for='ssid'>SSID</label><br>"
           "<input id='ssid' name='ssid' value='");
  out += htmlEscape(prefillSsid);
  out += F("' required><div style='height:10px'></div>"
           "<label for='pass'>Passwort</label><br>"
           "<input id='pass' name='pass' type='password' value=''>"
           "</form>"
           "<div style='height:12px'></div>"
           "<div class='row'>"
           "<button class='primary' type='submit' form='wifisave'>Verbinden</button>"
	           "<form method='POST' action='/wifi/reconnect' style='margin:0'>"
	           "<button type='submit'>Reconnect</button>"
	           "</form>"
	           "<a class='btn' href='/wifi/scanview?start=1' target='scanframe'>Scan</a>"
	           "<a class='btn' href='/wifi/scanview?cancel=1' target='scanframe' style='opacity:.85'>Stop</a>"
           "</div>"
           "<div style='height:12px'></div>"
           "<form method='POST' action='/wifi/forget' onsubmit='return confirm(&quot;Gespeichertes WLAN wirklich l&ouml;schen?&quot;);' style='margin:0'>"
           "<button type='submit'>WLAN vergessen</button>"
           "</form>");

	    out += F("<div style='height:14px'></div><h3 id='scan'>Scan</h3>"
           "<p class='muted'>Klicke auf <b>Scan</b> und w&auml;hle ein Netzwerk. Die Ergebnisse erscheinen hier, ohne dass die WiFi-Seite neu geladen wird.</p>"
           "<iframe name='scanframe' id='scanframe' src='/wifi/scanview' style='width:100%;border:0;height:300px;background:transparent'></iframe>");

out += F("</div>"); // WLAN ändern card

  pageEnd(out);
  _server.send(200, "text/html; charset=utf-8", out);
}


void NetworkService::handleWifiScanStart() {
  if (_ap.active) extendApTimeout();

  Log::addf("HTTP GET /wifi/scanstart");

  // If a scan is already running, just report "running".
  const int16_t st = WiFi.scanComplete();
  if (st == -1) {
    _webScanActive = true;
    _server.sendHeader("Cache-Control", "no-store");
    _server.sendHeader("Connection", "close");
    _server.send(200, "application/json; charset=utf-8", "{\"ok\":true,\"state\":\"running\"}");
    return;
  }

  // Avoid scan/connect races: if we're mid-connect, abort it for the scan.
  if (_staConnecting) abortStaConnect();

  const wifi_mode_t desired = _ap.active ? WIFI_AP_STA : WIFI_STA;
  if (WiFi.getMode() != desired) WiFi.mode(desired);
  WiFi.setSleep(false);

  WiFi.scanDelete();
  Log::addf("WiFi scan start (ajax)");
  WiFi.scanNetworks(true, true); // async

  _scanStartMs = millis();
  _scanRetryCount = 0;
  _scanZeroCount = 0;
  _webScanActive = true;

  _server.sendHeader("Cache-Control", "no-store");
  _server.sendHeader("Connection", "close");
  _server.send(200, "application/json; charset=utf-8", "{\"ok\":true,\"state\":\"started\"}");
}

void NetworkService::handleWifiScanCancel() {
  if (_ap.active) extendApTimeout();

  WiFi.scanDelete();
  _scanStartMs = 0;
  _scanRetryCount = 0;
  _scanZeroCount = 0;
  _webScanActive = false;

  _server.sendHeader("Cache-Control", "no-store");
  _server.sendHeader("Connection", "close");
  _server.send(200, "application/json; charset=utf-8", "{\"ok\":true,\"state\":\"idle\"}");
}

void NetworkService::handleWifiScanData() {
  if (_ap.active) extendApTimeout();

  static constexpr unsigned long SCAN_TIMEOUT_MS = 15000UL;
  static constexpr uint8_t FINALIZE_CYCLES = 4;

  int16_t st = WiFi.scanComplete();
  const unsigned long nowMs = millis();

  // -2 means: no scan started / no results available
  if (st == -2) {
    _webScanActive = false;
    _server.sendHeader("Cache-Control", "no-store");
    _server.sendHeader("Connection", "close");
    _server.send(200, "application/json; charset=utf-8", "{\"ok\":true,\"state\":\"idle\"}");
    return;
  }

  if (_scanStartMs == 0) _scanStartMs = nowMs;
  const unsigned long elapsed = nowMs - _scanStartMs;

  if (st == -1) {
    // running
    if (elapsed > SCAN_TIMEOUT_MS) {
      Log::addf("WiFi scan timeout");
      WiFi.scanDelete();
      _scanStartMs = 0;
      _scanRetryCount = 0;
      _scanZeroCount = 0;
      _webScanActive = false;

      _server.sendHeader("Cache-Control", "no-store");
      _server.sendHeader("Connection", "close");
      _server.send(200, "application/json; charset=utf-8", "{\"ok\":false,\"state\":\"timeout\"}");
      return;
    }

    int pct = 10 + (int)((elapsed * 80UL) / SCAN_TIMEOUT_MS);
    if (pct > 90) pct = 90;
    _webScanActive = true;

    String out;
    out.reserve(64);
    out += F("{\"ok\":true,\"state\":\"running\",\"progress\":");
    out += String(pct);
    out += F("}");
    _server.sendHeader("Cache-Control", "no-store");
    _server.sendHeader("Connection", "close");
    _server.send(200, "application/json; charset=utf-8", out);
    return;
  }

  if (st < 0) {
    // error
    Log::addf("WiFi scan failed (code=%d)", (int)st);
    WiFi.scanDelete();
    _scanStartMs = 0;
    _scanRetryCount = 0;
    _scanZeroCount = 0;
    _webScanActive = false;

    String out;
    out.reserve(80);
    out += F("{\"ok\":false,\"state\":\"error\",\"code\":");
    out += String(st);
    out += F("}");
    _server.sendHeader("Cache-Control", "no-store");
    _server.sendHeader("Connection", "close");
    _server.send(200, "application/json; charset=utf-8", out);
    return;
  }

  // st >= 0 : completed
  if (st == 0) {
    // Give the stack a few cycles to "settle" before calling it truly empty.
    if (_scanZeroCount < FINALIZE_CYCLES && elapsed < SCAN_TIMEOUT_MS) {
      _scanZeroCount++;
      _webScanActive = true;
      _server.sendHeader("Cache-Control", "no-store");
      _server.sendHeader("Connection", "close");
      _server.send(200, "application/json; charset=utf-8", "{\"ok\":true,\"state\":\"finalizing\",\"progress\":95}");
      return;
    }

    // Optional one-time retry for stacks that need a second scan
    if (_scanRetryCount < 1 && elapsed < SCAN_TIMEOUT_MS) {
      _scanRetryCount++;
      _scanZeroCount = 0;
      WiFi.scanDelete();
      Log::addf("WiFi scan returned 0 after finalizing -> retry (ajax)");
      WiFi.scanNetworks(true, true);
      _scanStartMs = millis();
      _webScanActive = true;

      _server.sendHeader("Cache-Control", "no-store");
      _server.sendHeader("Connection", "close");
      _server.send(200, "application/json; charset=utf-8", "{\"ok\":true,\"state\":\"running\",\"progress\":30}");
      return;
    }

    // Finally: empty
    WiFi.scanDelete();
    _scanStartMs = 0;
    _scanRetryCount = 0;
    _scanZeroCount = 0;
    _webScanActive = false;

    _server.sendHeader("Cache-Control", "no-store");
    _server.sendHeader("Connection", "close");
    _server.send(200, "application/json; charset=utf-8", "{\"ok\":true,\"state\":\"done\",\"count\":0,\"nets\":[]}");
    return;
  }

  // Build JSON with results (limit to reduce heap usage in crowded environments)
  static constexpr int MAX_SCAN_RESULTS = 25;
  const int shown = (st > MAX_SCAN_RESULTS) ? MAX_SCAN_RESULTS : st;
  String out;
  if (!out.reserve(256 + (size_t)shown * 96)) { _server.send(500, "application/json; charset=utf-8", "{\"ok\":false,\"err\":\"oom\"}"); return; }
  out += F("{\"ok\":true,\"state\":\"done\",\"total\":");
  out += String(st);
  out += F(",\"count\":");
  out += String(shown);
  out += F(",\"nets\":[");
  for (int i = 0; i < shown; i++) {
    const String ssid = WiFi.SSID(i);
    const int rssi = WiFi.RSSI(i);
    const int q = rssiToQualityPercent(rssi);
    const wifi_auth_mode_t enc = (wifi_auth_mode_t)WiFi.encryptionType(i);
    const bool open = (enc == WIFI_AUTH_OPEN);

    if (i) out += ',';
    out += F("{\"ssid\":\"");
    out += jsonEscape(ssid);
    out += F("\",\"q\":");
    out += String(q);
    out += F(",\"rssi\":");
    out += String(rssi);
    out += F(",\"open\":");
    out += open ? F("true") : F("false");
    out += '}';
  }
  out += F("]}");

  WiFi.scanDelete();
  _scanStartMs = 0;
  _scanRetryCount = 0;
  _scanZeroCount = 0;
  _webScanActive = false;

  _server.sendHeader("Cache-Control", "no-store");
  _server.sendHeader("Connection", "close");
  _server.send(200, "application/json; charset=utf-8", out);
}


void NetworkService::handleWifiScanView() {
  if (_ap.active) extendApTimeout();

  static constexpr unsigned long SCAN_TIMEOUT_MS = 15000UL;
  static constexpr uint8_t FINALIZE_CYCLES = 5;

  const bool doStart  = _server.hasArg("start")  && (_server.arg("start")  == "1");
  const bool doCancel = _server.hasArg("cancel") && (_server.arg("cancel") == "1");
  const unsigned long nowMs = millis();

  if (doCancel) {
    WiFi.scanDelete();
    _scanStartMs = 0;
    _scanRetryCount = 0;
    _scanZeroCount = 0;
    _webScanActive = false;

    String out;
  if (!out.reserve(1200)) { _server.send(500, "text/plain", "OOM"); return; }
    out += F("<!doctype html><html><head><meta charset='utf-8'>"
             "<meta name='viewport' content='width=device-width,initial-scale=1'>"
             "<style>"
             "body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Arial;"
             "color:#e7e7e7;background:transparent;}"
             ".box{padding:10px;border:1px solid rgba(255,255,255,.08);border-radius:14px;"
             "background:rgba(17,24,39,.55);}"
             ".muted{color:#a8b3c7}"
             "</style></head><body><div class='box'>"
             "<div class='muted'>Scan gestoppt.</div>"
             "</div></body></html>");

    _server.sendHeader("Cache-Control", "no-store");
    _server.sendHeader("Connection", "close");
    _server.send(200, "text/html; charset=utf-8", out);
    return;
  }

  int16_t st = WiFi.scanComplete();

  // Start scan (only if nothing started yet)
  if (doStart && st == -2) {
    if (_staConnecting) abortStaConnect();

    const wifi_mode_t desired = _ap.active ? WIFI_AP_STA : WIFI_STA;
    if (WiFi.getMode() != desired) WiFi.mode(desired);
    WiFi.setSleep(false);

    WiFi.scanDelete();
    Log::addf("WiFi scan start (frame)");
    WiFi.scanNetworks(true, true); // async

    _scanStartMs = nowMs;
    _scanRetryCount = 0;
    _scanZeroCount = 0;
    _webScanActive = true;
    st = -1;
  }

  // Track elapsed for timeout/progress
  if (_scanStartMs == 0 && st == -1) _scanStartMs = nowMs;
  const unsigned long elapsed = (_scanStartMs == 0) ? 0UL : (nowMs - _scanStartMs);

  // Build a minimal HTML fragment suitable for an iframe (no nav, no reload of parent page)
  String out;
  if (!out.reserve(9000)) { _server.send(500, "text/plain", "OOM"); return; }
  out += F("<!doctype html><html><head><meta charset='utf-8'>"
           "<meta name='viewport' content='width=device-width,initial-scale=1'>"
           "<style>"
           "body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Arial;"
           "color:#e7e7e7;background:transparent;}"
           ".box{padding:10px;border:1px solid rgba(255,255,255,.08);border-radius:14px;"
           "background:rgba(17,24,39,.55);}"
           ".muted{color:#a8b3c7}"
           ".bar{height:10px;border-radius:999px;background:rgba(255,255,255,.08);overflow:hidden;margin-top:8px}"
           ".barin{height:10px;border-radius:999px;background:rgba(16,185,129,.9);width:0%}"
           "ul{list-style:none;padding:0;margin:10px 0 0 0}"
           "li{padding:10px;border:1px solid rgba(255,255,255,.08);border-radius:12px;margin:8px 0;"
           "background:rgba(0,0,0,.12)}"
           ".row{display:flex;gap:10px;align-items:center;justify-content:space-between}"
           ".btn{display:inline-block;padding:8px 10px;border-radius:10px;"
           "border:1px solid rgba(255,255,255,.14);text-decoration:none;color:#e7e7e7;"
           "background:rgba(255,255,255,.06)}"
           ".btn:active{transform:translateY(1px)}"
           "</style>");

  auto addRefresh = [&](unsigned ms){
    const unsigned sec = (ms + 999U) / 1000U;
    out += F("<meta http-equiv='refresh' content='");
    out += String(sec);
    out += F(";url=/wifi/scanview?poll=1&_=");
    out += String(nowMs);
    out += F("'>");
  };

  // Render state
  out += F("</head><body><div class='box'>");

  if (st == -2) {
    _webScanActive = false;
    out += F("<div class='muted'>Noch kein Scan. Klicke oben auf <b>Scan</b>.</div>");
  } else if (st == -1) {
    // running
    if (elapsed > SCAN_TIMEOUT_MS) {
      Log::addf("WiFi scan timeout (frame)");
      WiFi.scanDelete();
      _scanStartMs = 0;
      _scanRetryCount = 0;
      _scanZeroCount = 0;
      _webScanActive = false;

      out += F("<div><b>Scan Timeout.</b></div><div class='muted'>Bitte erneut scannen.</div>");
    } else {
      int pct = 10 + (int)((elapsed * 80UL) / SCAN_TIMEOUT_MS);
      if (pct > 90) pct = 90;
      _webScanActive = true;

      out += F("<div class='muted'>Scanne... bitte warten</div>");
      out += F("<div class='bar'><div class='barin' style='width:");
      out += String(pct);
      out += F("%'></div></div>");
      addRefresh(1400);
    }
  } else if (st < 0) {
    // error
    Log::addf("WiFi scan failed (frame code=%d)", (int)st);
    WiFi.scanDelete();
    _scanStartMs = 0;
    _scanRetryCount = 0;
    _scanZeroCount = 0;
    _webScanActive = false;

    out += F("<div><b>Scan fehlgeschlagen.</b></div><div class='muted'>Code: ");
    out += String(st);
    out += F("</div>");
  } else if (st == 0) {
    // finalizing: some stacks return 0 briefly even when results appear a moment later
    if (_scanZeroCount < FINALIZE_CYCLES && elapsed < SCAN_TIMEOUT_MS) {
      _scanZeroCount++;
      _webScanActive = true;

      out += F("<div class='muted'>Scan abgeschlossen – Ergebnisse werden geladen...</div>");
      out += F("<div class='bar'><div class='barin' style='width:95%'></div></div>");
      addRefresh(900);
    } else {
      WiFi.scanDelete();
      _scanStartMs = 0;
      _scanRetryCount = 0;
      _scanZeroCount = 0;
      _webScanActive = false;

      out += F("<div class='muted'>0 Netzwerke gefunden.</div>");
      out += F("<div style='margin-top:10px'><a class='btn' href='/wifi/scanview?start=1' target='_self'>Erneut scannen</a></div>");
    }
  } else {
    // st > 0 -> results
    static constexpr int MAX_SCAN_RESULTS = 25;
    const int shown = (st > MAX_SCAN_RESULTS) ? MAX_SCAN_RESULTS : st;
    out += F("<div class='muted'>Gefundene Netzwerke: <b>");
    out += String(st);
    out += F("</b>");
    if (shown < st) {
      out += F(" <span class='muted'>(zeige ");
      out += String(shown);
      out += F(")</span>");
    }
    out += F("</div>");

    out += F("<ul>");
    for (int i = 0; i < shown; i++) {
      const String ssid = WiFi.SSID(i);
      const int rssi = WiFi.RSSI(i);
      const int q = rssiToQualityPercent(rssi);
      const wifi_auth_mode_t enc = (wifi_auth_mode_t)WiFi.encryptionType(i);
      const bool open = (enc == WIFI_AUTH_OPEN);

      out += F("<li><div class='row'><div><b>");
      out += htmlEscape(ssid);
      out += F("</b><br><span class='muted'>");
      out += String(q);
      out += F("% (");
      out += String(rssi);
      out += F(" dBm) &middot; ");
      out += open ? F("offen") : F("verschl.");
      out += F("</span></div>");

      out += F("<a class='btn' target='_top' href='/wifi?ssid=");
      out += urlEncode(ssid);
      out += F("#wifi-form'>Ausw&auml;hlen</a>");

      out += F("</div></li>");
    }
    out += F("</ul>");

    WiFi.scanDelete();
    _scanStartMs = 0;
    _scanRetryCount = 0;
    _scanZeroCount = 0;
    _webScanActive = false;
  }

  out += F("</div></body></html>");

  _server.sendHeader("Cache-Control", "no-store");
  _server.sendHeader("Connection", "close");
  _server.send(200, "text/html; charset=utf-8", out);
}

void NetworkService::handleWifiSave() {
  if (_ap.active) extendApTimeout();
  if (!_server.hasArg("ssid")) { _server.send(400, "text/plain", "missing arg: ssid"); return; }

  const String ssid = _server.arg("ssid");
  const String pass = _server.hasArg("pass") ? _server.arg("pass") : String();

  // Stop any in-progress scans / scan-mode gating before starting a connect.
  _webScanActive = false;
  _scanStartMs = 0;
  WiFi.scanDelete();

  requestStaConnect(ssid, pass, true);
  Log::addf("WiFi save: connect requested ssid='%s'", ssid.c_str());

  const String target = String("/wifi?connecting=1&ssid=") + urlEncode(ssid) + "#wifi-form";
  sendRedirectPage("WiFi", 1, "Verbinden", String("Verbinde mit <b>") + htmlEscape(ssid) + "</b> ...", target, 400);
}

void NetworkService::handleWifiForget() {
  if (_ap.active) extendApTimeout();
  _webScanActive = false;
  _scanStartMs = 0;
  WiFi.scanDelete();

  requestForgetWifi();
  Log::addf("WiFi forget requested");
  sendRedirectPage("WiFi", 1, "WLAN vergessen", "Gespeicherte WLAN-Daten werden gel&ouml;scht...", "/wifi#wifi-form", 500);
}

void NetworkService::handleWifiReconnect() {
  if (_ap.active) extendApTimeout();

  _webScanActive = false;
  _scanStartMs = 0;
  WiFi.scanDelete();

  if (WiFi.status() == WL_CONNECTED) {
    Log::addf("WiFi reconnect requested but already connected");
    sendRedirectPage("WiFi", 1, "Reconnect", "Schon verbunden &ndash; lade Status...", "/wifi#wifi-form", 350);
    return;
  }

  // If a connect attempt is in progress, abort it first (avoid scan/connect conflicts).
  if (_staConnecting) abortStaConnect();

  // Reconnect using stored credentials (if present).
  _pendingTriggerSync = true; // After connect: request NTP sync
  ensureStaConnectingKnown();
  Log::addf("WiFi reconnect requested (stored creds)");

  sendRedirectPage("WiFi", 1, "Reconnect", "Versuche, mit gespeicherten WLAN-Daten zu verbinden...", "/wifi?connecting=1#wifi-form", 400);
}

void NetworkService::handleRtcPage() {
  if (_ap.active) extendApTimeout();
  if (!_rtc) { _server.send(500, "text/plain", "RTC missing"); return; }

  sendHeader(F("RTC"));
  _server.sendContent(F("<h2>RTC (DS3231)</h2>"));

  _server.sendContent(F("<p><b>RTC aktiviert:</b> "));
  _server.sendContent(_rtc->enabled() ? F("Ja") : F("Nein"));
  _server.sendContent(F("<br><b>RTC erkannt:</b> "));
  _server.sendContent(_rtc->detected() ? F("Ja") : F("Nein"));
  _server.sendContent(F("<br><b>RTC-Zeit g&uuml;ltig:</b> "));
  _server.sendContent(_rtc->valid() ? F("Ja") : F("Nein"));
  _server.sendContent(F("</p>"));

  _server.sendContent(F("<form method='POST' action='/rtc/enable'>"
                        "<input type='hidden' name='enabled' value='"));
  _server.sendContent(_rtc->enabled() ? F("0") : F("1"));
  _server.sendContent(F("'><button type='submit'>"));
  _server.sendContent(_rtc->enabled() ? F("RTC deaktivieren") : F("RTC aktivieren"));
  _server.sendContent(F("</button></form>"));

  _server.sendContent(F("<h3>Zeit manuell setzen</h3>"
                        "<form method='POST' action='/rtc/set'>"
                        "<input type='datetime-local' name='datetime' required>"
                        "<button type='submit'>Zeit setzen</button></form>"));

  _server.sendContent(F("<p><a href='/'>Zur&uuml;ck</a></p>"));
  sendFooter();
}

void NetworkService::handleRtcEnable() {
  if (_ap.active) extendApTimeout();
  if (!_rtc) { _server.send(500, "text/plain", "RTC missing"); return; }
  if (!_server.hasArg("enabled")) { _server.send(400, "text/plain", "missing arg: enabled"); return; }

  const bool enabled = (_server.arg("enabled") == "1");
  _rtc->setEnabled(enabled);
  Log::addf("RTC enabled=%d", (int)enabled);

  // RTC wird auf der Startseite angezeigt
  _server.sendHeader("Location", "/", true);
  _server.send(303, "text/plain", "");
}

void NetworkService::handleRtcSet() {
  if (_ap.active) extendApTimeout();
  if (!_rtc) { _server.send(500, "text/plain", "RTC missing"); return; }
  if (!_server.hasArg("datetime")) { _server.send(400, "text/plain", "missing arg: datetime"); return; }

  const String dt = _server.arg("datetime");
  int year=0, mon=0, day=0, hour=0, min=0, sec=0;
  int parsed = sscanf(dt.c_str(), "%d-%d-%dT%d:%d:%d", &year, &mon, &day, &hour, &min, &sec);
  if (parsed < 5) { _server.send(400, "text/plain", "invalid datetime format"); return; }
  if (parsed == 5) sec = 0;

  tm tLocal{};
  tLocal.tm_year = year - 1900;
  tLocal.tm_mon  = mon - 1;
  tLocal.tm_mday = day;
  tLocal.tm_hour = hour;
  tLocal.tm_min  = min;
  tLocal.tm_sec  = sec;

  if (!_rtc->setSystemTimeFromLocalTm(tLocal)) {
    _server.send(500, "text/plain", "failed to set system time");
    Log::addf("Manual time set FAIL");
    return;
  }

  if (_time) _time->requestSyncNow();
  Log::addf("Manual time set OK -> request NTP");

  _server.sendHeader("Location", "/", true);
  _server.send(303, "text/plain", "");
}

void NetworkService::handleCaptiveRedirect() {
  const IPAddress ip = WiFi.softAPIP();
  const String url = String("http://") + ip.toString() + "/wifi";
  _server.sendHeader("Location", url, true);
  _server.send(302, "text/plain", "");
}

void NetworkService::handleNotFound() {
  if (_ap.active) { handleCaptiveRedirect(); return; }
  _server.send(404, "text/plain", "Not Found\n");
}

// ===================== TimeService impl =====================
bool TimeService::systemTimeValid() const {
  time_t now; time(&now);
  return now > 100000;
}

unsigned long TimeService::lastSyncMinutesAgo() const {
  if (!_st.lastSyncEver || _st.lastSyncMillis == 0) return 0;
  return (millis() - _st.lastSyncMillis) / 60000UL;
}

long TimeService::nextSyncInSeconds() const {
  time_t now; time(&now);
  if (_st.nextSyncEpoch > 0 && systemTimeValid()) return (long)(_st.nextSyncEpoch - now);
  if (_st.nextRetryMillis > 0) {
    long diffMs = (long)(millis() - _st.nextRetryMillis);
    return -(diffMs / 1000L);
  }
  return -1;
}

void TimeService::scheduleNextAfterOk() {
  time_t now; time(&now);
  _st.timeValid = systemTimeValid();
  _st.nextRetryMillis = 0;
  _st.nextSyncEpoch = now + UPDATE_DELAY_SEC;
}

void TimeService::scheduleRetryNoTime() {
  _st.timeValid = systemTimeValid();
  if (_st.timeValid) {
    time_t now; time(&now);
    _st.nextSyncEpoch = now + RETRY_DELAY_SEC;
    _st.nextRetryMillis = 0;
  } else {
    _st.nextSyncEpoch = 0;
    _st.nextRetryMillis = millis() + (RETRY_DELAY_SEC * 1000UL);
  }
}

void TimeService::begin(NetworkService* net, RtcService* rtc) {
  _net = net;
  _rtc = rtc;

  sntp_set_time_sync_notification_cb(ntpTimeSyncCallback);

  if (_rtc && _rtc->tryApplyRtcToSystem()) {
    _st.timeValid = systemTimeValid();
    _st.rtcClockMode = true;

    // RTC gibt eine plausible Startzeit, aber nach Boot soll (wenn WLAN vorhanden) immer NTP versucht werden.
    time_t now; time(&now);
    _st.nextSyncEpoch = now;  // sofort fällig
    _st.nextRetryMillis = 0;

    _ntpServerIndex = 0;
    _ntpAttempt = 0;

    Log::addf("Boot: RTC time OK (rtcClockMode=1) -> immediate NTP scheduled");
  } else {
    _st.timeValid = false;
    _st.rtcClockMode = false;
    _st.nextSyncEpoch = 0;
    _st.nextRetryMillis = millis();
    Log::addf("Boot: no RTC time -> NTP retry now");

    _ntpServerIndex = 0;
    _ntpAttempt = 0;
  }

  _phase = Phase::Idle;
}

void TimeService::loop() {
  const unsigned long nowMs = millis();
  if (nowMs - _lastLoopMs < 100) return;
  _lastLoopMs = nowMs;

  if (_syncNow) {
    _syncNow = false;
    if (systemTimeValid()) {
      time_t now; time(&now);
      _st.nextSyncEpoch = now;
      _st.nextRetryMillis = 0;
    } else {
      _st.nextSyncEpoch = 0;
      _st.nextRetryMillis = nowMs;
    }
    Log::addf("SyncNow scheduled");
  }

  _st.syncInProgress = (_phase != Phase::Idle && _phase != Phase::FinishedOk && _phase != Phase::FinishedFail);

  if (_phase == Phase::FinishedOk || _phase == Phase::FinishedFail) {
    _phase = Phase::Idle;
    return;
  }

  bool due = false;
  if (systemTimeValid() && _st.nextSyncEpoch > 0) {
    time_t now; time(&now);
    if (now >= _st.nextSyncEpoch) due = true;
  } else if (!systemTimeValid() && _st.nextRetryMillis > 0) {
    if ((long)(nowMs - _st.nextRetryMillis) >= 0) due = true;
  }

  if (!due && _phase == Phase::Idle) return;

  if (_phase == Phase::Idle) {
    // Start einer neuen Sync-Session: Fallback-Rotation zurücksetzen
    _ntpServerIndex = 0;
    _ntpAttempt = 0;

    _phase = Phase::WaitWifi;
    _wifiDeadlineMs = nowMs + WIFI_CONNECT_TIMEOUT_MS;
    _net->ensureStaConnectingKnown();
    Log::addf("Sync: waiting for WiFi...");
    return;
  }

  if (_phase == Phase::WaitWifi) {
    if (_net->isStaConnected()) {
      _phase = Phase::StartNtp;
      return;
    }

    if (_net->staConnectFailed() || (long)(nowMs - _wifiDeadlineMs) >= 0) {
      _net->abortStaConnect();

      const bool rtcOk = (_rtc && _rtc->tryApplyRtcToSystem());
      _st.lastSyncEver = true;
      _st.lastSyncOk = false;

      if (rtcOk) {
        _st.timeValid = systemTimeValid();
        _st.rtcClockMode = true;
        time_t now; time(&now);
        _st.nextSyncEpoch = now + RETRY_DELAY_SEC; // RTC OK, aber NTP zeitnah erneut versuchen
        _st.nextRetryMillis = 0;
        Log::addf("Sync: WiFi failed -> RTC fallback OK");
      } else {
        _st.timeValid = systemTimeValid();
        _st.rtcClockMode = false;
        scheduleRetryNoTime();
        Log::addf("Sync: WiFi failed -> RTC fallback FAIL -> retry scheduled");
        if (!CONTINUOUS_WIFI && !_net->isApActive()) _net->startAp(false);
      }

      _net->powerOffWifiIfAllowed();
      _phase = Phase::FinishedFail;
      return;
    }
    return;
  }

  if (_phase == Phase::StartNtp) {
    _ntpCounterStart = gNtpSyncEventCounter;
    if (sntp_enabled()) sntp_stop();

    // 4 Server (primary + 3 fallbacks). Pro Versuch 3 Server konfigurieren, rotierend.
    const uint8_t i0 = (uint8_t)(_ntpServerIndex % NTP_SERVER_COUNT);
    const uint8_t i1 = (uint8_t)((i0 + 1) % NTP_SERVER_COUNT);
    const uint8_t i2 = (uint8_t)((i0 + 2) % NTP_SERVER_COUNT);

    configTzTime(TZ_INFO, NTP_SERVERS[i0], NTP_SERVERS[i1], NTP_SERVERS[i2]);

    _ntpDeadlineMs = nowMs + NTP_WAIT_TIMEOUT_MS;
    _phase = Phase::WaitNtp;

    Log::addf("NTP started (servers=%s,%s,%s attempt=%u)",
              NTP_SERVERS[i0], NTP_SERVERS[i1], NTP_SERVERS[i2], (unsigned)_ntpAttempt);
    return;
  }

  if (_phase == Phase::WaitNtp) {
    const bool gotEvent = (gNtpSyncEventCounter != _ntpCounterStart);


    if (gotEvent && gNtpSyncEventFlag) {
      gNtpSyncEventFlag = false;
      Log::addf("SNTP time sync event received");
    }
    if (gotEvent && systemTimeValid()) {
      _st.timeValid = true;
      _st.rtcClockMode = false;

      _st.lastSyncEver = true;
      _st.lastSyncOk = true;
      _st.lastSyncMillis = millis();
      time_t now; time(&now);
      _st.lastSyncEpoch = now;

      scheduleNextAfterOk();
      if (_rtc) _rtc->writeSystemToRtc();

      Log::addf("NTP sync OK");

      _ntpServerIndex = 0;
      _ntpAttempt = 0;

      if (_net->isApActive() && !_net->isApManual()) {
        const int clients = WiFi.softAPgetStationNum();
        if (clients == 0) _net->stopAp();
        else Log::addf("AP kept running after NTP sync: %d client(s) connected", clients);
      }

      _net->powerOffWifiIfAllowed();
      _phase = Phase::FinishedOk;
      return;
    }

    if ((long)(nowMs - _ntpDeadlineMs) >= 0) {
      // Timeout: erst NTP-Fallback-Server rotierend versuchen (bis zu 3 Fallbacks),
      // bevor wir auf RTC/Retry-Fallback gehen.
      if (_ntpAttempt < (NTP_SERVER_COUNT - 1)) {
        _ntpAttempt++;
        _ntpServerIndex = (uint8_t)((_ntpServerIndex + 1) % NTP_SERVER_COUNT);
        _phase = Phase::StartNtp;
        Log::addf("NTP timeout -> retry with fallback servers (attempt=%u)", (unsigned)_ntpAttempt);
        return;
      }


      const bool rtcOk = (_rtc && _rtc->tryApplyRtcToSystem());

      _st.lastSyncEver = true;
      _st.lastSyncOk = false;

      if (rtcOk) {
        _st.timeValid = true;
        _st.rtcClockMode = true;
        time_t now; time(&now);
        _st.nextSyncEpoch = now + RETRY_DELAY_SEC; // RTC OK, aber NTP zeitnah erneut versuchen
        _st.nextRetryMillis = 0;
        Log::addf("NTP timeout -> RTC fallback OK");
      } else {
        _st.timeValid = systemTimeValid();
        _st.rtcClockMode = false;
        scheduleRetryNoTime();
        Log::addf("NTP timeout -> RTC fallback FAIL -> retry scheduled");
        if (!CONTINUOUS_WIFI && !_net->isApActive()) _net->startAp(false);
      }

      _net->powerOffWifiIfAllowed();
      _phase = Phase::FinishedFail;
      return;
    }
    return;
  }
}

// ===================== Singletons + API for main.cpp =====================
static RtcService gRtc;
static NetworkService gNet;
static TimeService gTime;

void services_setup() {
  Log::addf("Boot start");
  gRtc.begin();
  gNet.begin(&gTime, &gRtc);
  gTime.begin(&gNet, &gRtc);
  Log::addf("Boot done");
}

void services_loop() {
  gNet.loop();
  gTime.loop();
}