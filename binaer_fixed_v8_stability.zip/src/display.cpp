#include <Arduino.h>
#include <time.h>
#include <sys/time.h>
#include <math.h>

// ====== Pins / Tuning (müssen zu services.cpp passen) ======
static constexpr uint8_t LED_PWM_CHANNEL            = 0;
static constexpr uint8_t ANALOGUE_DISPLAY_CHANNEL   = 1;
static constexpr uint8_t ANALOGUE_BACKLIGHT_CHANNEL = 2;

static constexpr uint32_t LED_PWM_FREQ_HZ           = 4000;
static constexpr uint8_t  LED_PWM_BITS              = 8;

static constexpr uint32_t ANALOGUE_PWM_FREQ_HZ      = 4000;
static constexpr uint8_t  ANALOGUE_DISPLAY_PWM_BITS = 10;

static constexpr uint32_t BACKLIGHT_PWM_FREQ_HZ     = 4000;
static constexpr uint8_t  BACKLIGHT_PWM_BITS        = 8;

static constexpr uint16_t VOLTMETER_PWM_MAX_TUNING  = 236;

static constexpr uint8_t  PHOTO_FILTER_SHIFT        = 3;
static constexpr int      ANALOGUE_BACKLIGHT_ON_LIMIT  = 2000;
static constexpr int      ANALOGUE_BACKLIGHT_OFF_LIMIT = 2500;
static constexpr uint8_t  LED_BRIGHTNESS_MIN        = 8;
static constexpr uint8_t  LED_BRIGHTNESS_MAX        = 180;
static constexpr int      LED_BRIGHTNESS_MIN_PWM    = 950;

static constexpr uint32_t DISPLAY_UPDATE_MS         = 50;
static constexpr uint32_t BRIGHTNESS_UPDATE_MS      = 100;

// Minuten LEDs
static constexpr int LED_MIN_1_PIN  = 23;
static constexpr int LED_MIN_2_PIN  = 22;
static constexpr int LED_MIN_4_PIN  = 21;
static constexpr int LED_MIN_8_PIN  = 19;
static constexpr int LED_MIN_16_PIN = 18;
static constexpr int LED_MIN_32_PIN = 2;

// Stunden LEDs
static constexpr int LED_HOUR_1_PIN  = 26;
static constexpr int LED_HOUR_2_PIN  = 27;
static constexpr int LED_HOUR_4_PIN  = 14;
static constexpr int LED_HOUR_8_PIN  = 12;
static constexpr int LED_HOUR_16_PIN = 13;

// Analog-Sekunden + Backlight
static constexpr int ANALOGUE_SECONDS_PIN   = 25;
static constexpr int ANALOGUE_BACKLIGHT_PIN = 4;

// Lichtsensor (ADC)
static constexpr int PHOTO_PIN = 34;

// ====== LED Arrays ======
static constexpr int MINUTE_LED_COUNT = 6;
static constexpr int HOUR_LED_COUNT   = 5;

static const int minuteLeds[MINUTE_LED_COUNT] = {
  LED_MIN_1_PIN, LED_MIN_2_PIN, LED_MIN_4_PIN, LED_MIN_8_PIN, LED_MIN_16_PIN, LED_MIN_32_PIN
};

static const int hourLeds[HOUR_LED_COUNT] = {
  LED_HOUR_1_PIN, LED_HOUR_2_PIN, LED_HOUR_4_PIN, LED_HOUR_8_PIN, LED_HOUR_16_PIN
};

static void assignNumToLeds(int num, const int* leds, int count) {
  for (int i = count - 1; i >= 0; i--) {
    if (bitRead(num, i)) {
      ledcAttachPin(leds[i], LED_PWM_CHANNEL);
    } else {
      ledcDetachPin(leds[i]);
    }
  }
}

static void displaySecondsVoltmeterSmooth(float secondsInMinute) {
  if (secondsInMinute < 0.0f) secondsInMinute = 0.0f;
  while (secondsInMinute >= 60.0f) secondsInMinute -= 60.0f;

  const float pwmRaw    = secondsInMinute * 256.0f / 60.0f;       // 0.. <256
  const float pwmFolded = (pwmRaw <= 128.0f) ? pwmRaw : (256.0f - pwmRaw);

  const uint16_t meterPwm = (uint16_t)lroundf((pwmFolded / 128.0f) * (float)VOLTMETER_PWM_MAX_TUNING);
  ledcWrite(ANALOGUE_DISPLAY_CHANNEL, meterPwm);
}

static void displayTask(void* param) {
  (void)param;

  ledcSetup(LED_PWM_CHANNEL,            LED_PWM_FREQ_HZ,           LED_PWM_BITS);
  ledcSetup(ANALOGUE_DISPLAY_CHANNEL,   ANALOGUE_PWM_FREQ_HZ,      ANALOGUE_DISPLAY_PWM_BITS);
  ledcSetup(ANALOGUE_BACKLIGHT_CHANNEL, BACKLIGHT_PWM_FREQ_HZ,     BACKLIGHT_PWM_BITS);

  ledcAttachPin(ANALOGUE_SECONDS_PIN, ANALOGUE_DISPLAY_CHANNEL);

  bool backlightAttached = false;
  int photoFiltered = -1;

  int lastMinute = -1;
  int lastHour = -1;
  int lastWholeSecond = -1;

  unsigned long lastBrightnessUpdate = 0;

  for (;;) {
    timeval tv{};
    gettimeofday(&tv, nullptr);
    const time_t now = tv.tv_sec;

    if (now > 100000) {
      const float secInMinute = (float)(now % 60) + ((float)tv.tv_usec / 1000000.0f);
      displaySecondsVoltmeterSmooth(secInMinute);

      const int wholeSec = (int)(now % 60);
      if (wholeSec != lastWholeSecond) {
        tm localTm{};
        if (localtime_r(&now, &localTm)) {
          if (localTm.tm_min != lastMinute) {
            assignNumToLeds(localTm.tm_min, minuteLeds, MINUTE_LED_COUNT);
            lastMinute = localTm.tm_min;
          }
          if (localTm.tm_hour != lastHour) {
            assignNumToLeds(localTm.tm_hour, hourLeds, HOUR_LED_COUNT);
            lastHour = localTm.tm_hour;
          }
          lastWholeSecond = localTm.tm_sec;
        }
      }
    } else {
      displaySecondsVoltmeterSmooth(0.0f);
    }

    const unsigned long nowMs = millis();
    if (nowMs - lastBrightnessUpdate >= BRIGHTNESS_UPDATE_MS) {
      lastBrightnessUpdate = nowMs;

      const int photoRaw = analogRead(PHOTO_PIN);
      if (photoFiltered < 0) {
        photoFiltered = photoRaw;
      } else {
        photoFiltered = ((photoFiltered * ((1 << PHOTO_FILTER_SHIFT) - 1)) + photoRaw) >> PHOTO_FILTER_SHIFT;
      }

      int photoValue = photoFiltered;
      if (photoValue < LED_BRIGHTNESS_MIN_PWM) photoValue = LED_BRIGHTNESS_MIN_PWM;
      if (photoValue > 4095) photoValue = 4095;

      const uint8_t ledBrightness = (uint8_t)map(photoValue, LED_BRIGHTNESS_MIN_PWM, 4095, LED_BRIGHTNESS_MIN, LED_BRIGHTNESS_MAX);
      ledcWrite(LED_PWM_CHANNEL, ledBrightness);

      ledcWrite(ANALOGUE_BACKLIGHT_CHANNEL, 255);

      if (photoValue < ANALOGUE_BACKLIGHT_ON_LIMIT && !backlightAttached) {
        ledcAttachPin(ANALOGUE_BACKLIGHT_PIN, ANALOGUE_BACKLIGHT_CHANNEL);
        backlightAttached = true;
      } else if (photoValue > ANALOGUE_BACKLIGHT_OFF_LIMIT && backlightAttached) {
        ledcDetachPin(ANALOGUE_BACKLIGHT_PIN);
        backlightAttached = false;
      }
    }

    vTaskDelay(pdMS_TO_TICKS(DISPLAY_UPDATE_MS));
  }
}

// Display auf Core 0 pinnen (Loop/Webserver läuft i.d.R. auf Core 1)
void display_start_task_core0() {
  xTaskCreatePinnedToCore(displayTask, "displayTask", 4096, nullptr, 1, nullptr, 0);
}